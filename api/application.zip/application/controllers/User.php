<?php

defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';
use Restserver\Libraries\REST_Controller;

class User extends REST_Controller {

    function __construct($config = 'rest') {
        parent::__construct($config);
        $this->load->database();
    }

    //Menampilkan data kontak
    function index_get() {
        $email = $this->get('email');
        $this->db->join('tb_dapil', 'tb_dapil.id_dapil = users.dapil', 'left');
        $this->db->join('tb_fraksi', 'tb_fraksi.id_fraksi = users.fraksi', 'left');
        $this->db->join('tb_jabatan', 'tb_jabatan.id_jabatan = users.jabatan', 'left');
        
        if ($email == '') {
            $kontak = $this->db->get('users')->result();
        } else {
            $this->db->where('email', $email);
            $kontak = $this->db->get('users')->result();
        }
        $this->response($kontak, 200);
    }

    //Masukan function selanjutnya disini
}
?>