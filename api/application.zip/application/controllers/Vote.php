<?php

defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';
use Restserver\Libraries\REST_Controller;

class Vote extends REST_Controller {

    function __construct($config = 'rest') {
        parent::__construct($config);
        $this->load->database();
    }

    //Menampilkan data kontak
    function index_get() {
        $id = $this->get('id');
        if ($id == '') {
            $kontak = $this->db->get('tb_vote')->result();
        } else {
            $this->db->where('id_vote', $id);
            $kontak = $this->db->get('tb_vote')->result();
        }
        $this->response($kontak, 200);
    }

    function index_post() {
        $data = array(
                'id_vote'   => '',
                'createdat_vote'   => '',
                'user_vote'   => $this->post('user_vote'),
                'agenda_vote' => $this->post('agenda_vote'),
                'is_vote'   => $this->post('is_vote'));

        $insert = $this->db->insert('tb_vote', $data);
        if ($insert) {
            $this->response($data, 200);
        } else {
            $this->response(array('status' => 'fail', 502));
        }
    }
    //Masukan function selanjutnya disini

    
}
?>